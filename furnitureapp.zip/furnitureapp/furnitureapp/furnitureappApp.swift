//
//  furnitureappApp.swift
//  furnitureapp
//
//  Created by Muhammad Ahmed on 24/07/2023.
//

import SwiftUI

@main
struct furnitureappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
