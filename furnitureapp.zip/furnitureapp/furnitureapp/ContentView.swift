//
//  ContentView.swift
//  furnitureapp
//
//  Created by Muhammad Ahmed on 24/07/2023.
//

import SwiftUI

struct ContentView: View {
   
    var body: some View {
        VStack {
            HomeScreen()
        }

    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}





